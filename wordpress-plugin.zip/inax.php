<?php
/*
Plugin Name: افزونه خرید شارژ و پرداخت قبض آینکس
Plugin URI:  https://inax.ir
Description: توسط این پلاگین میتوانید امکان خرید شارژ، بسته اینترنت و پرداخت قبض را به وب سایت خود اضافه کرده و کسب درآمد کنید.
Version:     1.0
Author:      Mohammad Moradpour
Author URI:  https://inax.ir
License:     GPL2 etc
License URI: https://inax.ir
*/

defined('INAX_DIR') or define('INAX_DIR',  dirname(__FILE__).DIRECTORY_SEPARATOR);
defined('INAX_Main_File_Path') or define('INAX_Main_File_Path',  __FILE__ );//db.php


require_once( dirname( __FILE__ ) .'/db.php' );


// do you have a session id
//$s_id = session_id();
//print_r($s_id);

// can you declare a bogus session variable, yours might just be empty
//$_SESSION['bogus'] = 'bogus';
//print_r($_SESSION);

//add_action('init', 'register_session', 1);


/**
 * init function
 * @global type $inax_option
 */
function inax_init() {
    global $inax_option;
    $db_options 	= get_option('inax_options');
    $inax_option 	= json_decode($db_options, TRUE);
    /* =================================================================== */
}
inax_init();

/**
 * Setup plugin page option link
 */
function inax_add_settings_link( $links ) {
    $settings_link = '<a href="'.menu_page_url('inax_admin_page',FALSE).'">'.__('setting','inax').'</a>';
    Array_unshift( $links, $settings_link );
    return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'inax_add_settings_link' );


/**
 * Setup language text domain
 */
load_plugin_textdomain('inax', false, basename(dirname(__FILE__)).'/languages');


require_once( dirname( __FILE__ ) .'/admin.php' );

//include css & js to wordpress header
add_action('wp_enqueue_scripts', 'callback_for_setting_up_scripts');
function callback_for_setting_up_scripts() {
    wp_register_style( 'namespace',  plugins_url('/templates/css/bootstrap.my.css',__FILE__ ) );
	wp_register_style( 'my_style',  plugins_url('/templates/css/style.css',__FILE__ ) );
    wp_enqueue_style( 'namespace' ); 
	wp_enqueue_style( 'my_style' );
	
    //wp_enqueue_script( 'namespaceformyscript', plugins_url('/templates/js/jquery-1.12.3.min.js',__FILE__ ) , array( 'jquery' ) );
	wp_enqueue_script( 'namespaceformyscript', plugins_url('/assets/js/jquery-1.12.3.min.js',__FILE__ ) );
	wp_enqueue_script( 'inax_bootstrap', plugins_url('/assets/js/bootstrap.min.js',__FILE__ ) );
}




//ajax js file
add_action( 'wp_enqueue_scripts', 'inax_ajax_scripts' );
function inax_ajax_scripts(){
	wp_register_script( 'ajaxHandle', plugins_url('/assets/js/check_bill_ajax.js',__FILE__ ), array(), false, true );
	wp_enqueue_script( 'ajaxHandle' );
	wp_localize_script('ajaxHandle', 'ajax_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
}

//string check_bill at the end of wp_ajax_check_bill & wp_ajax_nopriv_check_bill must be some as in check_bill_ajax.js action parameter value
add_action( "wp_ajax_check_bill", "check_ajax_function" );
add_action( "wp_ajax_nopriv_check_bill", "check_ajax_function" );
function check_ajax_function(){ 
	include INAX_DIR . DIRECTORY_SEPARATOR . 'ajax_check_bill.php';
	//echo json_encode( array( "error_msg"=>'ddddddddddddddd' ) ); 
	wp_die(); // ajax call must die to avoid trailing 0 in your response
}
//ajax


function inax_plugin( $content ){
	global $wpdb;
	
	//$mysqli = $wpdb;
	//global $wp_query;
	//print_r($wp_query);
	//$post_id	= $wp_query->post->ID;
	//$pagename 	= $wp_query->pagename;
	
	/*
	///if ( is_page() || is_archive() )
			
		$post = get_post();
 		if ( is_page() ) {
			echo 'aaaaaaaaaaaaaaaaaaa';
		} else {
			echo 'bbbbbbbbbbbbbbbbbbbbb';
		}
	*/
	$srvr ='';
	foreach($_SERVER as $key => $server){
		$srvr .= "$key = $server" . "<br/>";
	}
	//error_log( ' -------- SERVER -------- '. print_r($srvr,true) ) ;
	
		
	//عدم نمایش خرید شارژ در ویرایشگر مدیریت وردپرس
	//عدم ورود به این بخش در حین ذخیره نوشته
	if( !isset($_GET['action']) && (strpos($_SERVER['HTTP_REFERER'], 'action=edit')===false) ){

		//اگر در متن نوشته عبارت های زیر باشد
		if( ( strpos($content, '[topup]')!==false || strpos($content, '[pin]')!==false || strpos($content, '[bill]')!==false || strpos($content, '[internet]')!==false ) ){
			require_once( dirname( __FILE__ ) .'/load.php' );
				
			if( strpos($content, '[topup]')!==false ){
				include( dirname( __FILE__ ) . '/topup.php' );
			}
			else if( strpos($content, '[pin]')!==false ){
				include( dirname( __FILE__ ) . '/pin.php' );
			}
			else if( strpos($content, '[bill]')!==false ){
				include( dirname( __FILE__ ) . '/bill.php' );
			}
			else if( strpos($content, '[internet]')!==false ){
				include( dirname( __FILE__ ) . '/internet.php' );
			}
			
			//remove [topup], ... from content
			$content = str_replace( array("[topup]","[pin]","[bill]","[internet]") ,array("","","",""), $content, $matches);
		}
	}
    return $content;
}
add_filter( 'the_content', 'inax_plugin' );
?>